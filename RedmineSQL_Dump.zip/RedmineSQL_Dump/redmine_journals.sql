-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: redmine
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `journals`
--

DROP TABLE IF EXISTS `journals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `journals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `journalized_id` int NOT NULL DEFAULT '0',
  `journalized_type` varchar(30) NOT NULL DEFAULT '',
  `user_id` int NOT NULL DEFAULT '0',
  `notes` longtext,
  `created_on` datetime NOT NULL,
  `private_notes` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `journals_journalized_id` (`journalized_id`,`journalized_type`),
  KEY `index_journals_on_user_id` (`user_id`),
  KEY `index_journals_on_journalized_id` (`journalized_id`),
  KEY `index_journals_on_created_on` (`created_on`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journals`
--

LOCK TABLES `journals` WRITE;
/*!40000 ALTER TABLE `journals` DISABLE KEYS */;
INSERT INTO `journals` VALUES (1,1,'Issue',1,'','2023-03-14 12:39:30',0),(2,2,'Issue',1,'','2023-03-14 12:39:30',0),(3,2,'Issue',1,'','2023-03-14 12:40:38',0),(4,3,'Issue',1,'','2023-03-14 12:40:38',0),(5,4,'Issue',1,'','2023-03-14 12:45:54',0),(6,5,'Issue',1,'','2023-03-14 12:45:54',0),(7,4,'Issue',1,'','2023-03-14 12:46:00',0),(8,5,'Issue',1,'','2023-03-14 12:46:00',0),(9,2,'Issue',1,'','2023-03-14 12:46:09',0),(10,3,'Issue',1,'','2023-03-14 12:46:09',0),(11,1,'Issue',1,'','2023-03-14 12:46:21',0),(12,2,'Issue',1,'','2023-03-14 12:46:21',0),(13,5,'Issue',1,'','2023-03-14 12:52:22',0),(14,4,'Issue',1,'','2023-03-14 12:52:28',0),(15,7,'Issue',1,'','2023-03-14 13:08:13',0),(16,1,'Issue',1,'','2023-03-14 13:08:25',0),(17,2,'Issue',1,'','2023-03-14 13:08:35',0),(18,5,'Issue',1,'','2023-03-14 13:08:48',0),(19,6,'Issue',1,'','2023-03-14 13:08:57',0),(20,3,'Issue',1,'','2023-03-14 13:09:03',0),(21,7,'Issue',1,'','2023-03-14 13:15:10',0),(22,8,'Issue',1,'','2023-03-14 13:15:10',0),(23,8,'Issue',1,'','2023-03-14 13:15:32',0),(24,9,'Issue',1,'','2023-03-14 13:15:32',0),(25,8,'Issue',1,'','2023-03-14 13:15:38',0),(26,9,'Issue',1,'','2023-03-14 13:15:38',0),(27,7,'Issue',1,'','2023-03-14 13:15:45',0),(28,8,'Issue',1,'','2023-03-14 13:15:45',0),(29,8,'Issue',1,'','2023-03-14 13:16:01',0),(30,9,'Issue',1,'','2023-03-14 13:16:06',0),(31,10,'Issue',1,'','2023-03-14 13:17:16',0),(32,10,'Issue',1,'','2023-03-14 13:17:38',0),(33,11,'Issue',1,'','2023-03-14 13:17:38',0),(34,10,'Issue',1,'','2023-03-14 13:17:47',0),(35,11,'Issue',1,'','2023-03-14 13:17:47',0),(36,10,'Issue',1,'','2023-03-14 13:18:22',0),(37,10,'Issue',1,'','2023-03-14 13:19:07',0),(38,11,'Issue',1,'','2023-03-14 13:19:12',0),(39,12,'Issue',1,'','2023-03-14 13:24:02',0),(40,4,'Issue',1,'','2023-03-14 13:25:05',0),(41,14,'Issue',1,'','2023-03-14 13:33:05',0),(42,16,'Issue',1,'','2023-03-14 13:33:05',0),(43,16,'Issue',1,'','2023-03-14 13:33:17',0),(44,14,'Issue',1,'','2023-03-14 13:33:21',0),(45,16,'Issue',1,'','2023-03-14 13:33:21',0),(46,15,'Issue',1,'','2023-03-14 13:33:54',0),(47,19,'Issue',1,'','2023-03-14 13:35:31',0),(48,13,'Issue',1,'','2023-03-14 13:55:53',0),(49,14,'Issue',1,'','2023-03-14 13:55:57',0),(50,18,'Issue',1,'','2023-03-14 13:56:07',0);
/*!40000 ALTER TABLE `journals` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-14 16:06:09
