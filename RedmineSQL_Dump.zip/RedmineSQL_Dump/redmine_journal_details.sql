-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: redmine
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `journal_details`
--

DROP TABLE IF EXISTS `journal_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `journal_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `journal_id` int NOT NULL DEFAULT '0',
  `property` varchar(30) NOT NULL DEFAULT '',
  `prop_key` varchar(30) NOT NULL DEFAULT '',
  `old_value` longtext,
  `value` longtext,
  PRIMARY KEY (`id`),
  KEY `journal_details_journal_id` (`journal_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_details`
--

LOCK TABLES `journal_details` WRITE;
/*!40000 ALTER TABLE `journal_details` DISABLE KEYS */;
INSERT INTO `journal_details` VALUES (1,1,'relation','copied_to',NULL,'2'),(2,2,'relation','copied_from',NULL,'1'),(3,3,'relation','copied_to',NULL,'3'),(4,4,'relation','copied_from',NULL,'2'),(5,5,'relation','copied_to',NULL,'5'),(6,6,'relation','copied_from',NULL,'4'),(7,7,'relation','copied_to','5',NULL),(8,8,'relation','copied_from','4',NULL),(9,9,'relation','copied_to','3',NULL),(10,10,'relation','copied_from','2',NULL),(11,11,'relation','copied_to','2',NULL),(12,12,'relation','copied_from','1',NULL),(13,13,'attr','fixed_version_id',NULL,'1'),(14,14,'attr','fixed_version_id',NULL,'1'),(15,15,'attr','status_id','1','5'),(16,16,'attr','status_id','1','2'),(17,17,'attr','status_id','1','2'),(18,18,'attr','status_id','1','2'),(19,19,'attr','status_id','1','6'),(20,20,'attr','status_id','1','2'),(21,21,'relation','copied_to',NULL,'8'),(22,22,'relation','copied_from',NULL,'7'),(23,23,'relation','copied_to',NULL,'9'),(24,24,'relation','copied_from',NULL,'8'),(25,25,'relation','copied_to','9',NULL),(26,26,'relation','copied_from','8',NULL),(27,27,'relation','copied_to','8',NULL),(28,28,'relation','copied_from','7',NULL),(29,29,'attr','status_id','1','5'),(30,30,'attr','status_id','1','5'),(31,31,'attr','status_id','1','3'),(32,32,'relation','copied_to',NULL,'11'),(33,33,'relation','copied_from',NULL,'10'),(34,34,'relation','copied_to','11',NULL),(35,35,'relation','copied_from','10',NULL),(36,36,'attr','done_ratio','0','100'),(37,37,'attr','status_id','3','5'),(38,38,'attr','status_id','1','5'),(39,39,'attr','status_id','1','5'),(40,40,'attr','status_id','1','4'),(41,41,'relation','copied_to',NULL,'16'),(42,42,'relation','copied_from',NULL,'14'),(43,43,'attr','subject','Функциональная возможность 2','Функциональная возможность 3'),(44,44,'relation','copied_to','16',NULL),(45,45,'relation','copied_from','14',NULL),(46,46,'attr','child_id',NULL,'17'),(47,47,'attr','status_id','1','5'),(48,48,'attr','status_id','1','2'),(49,49,'attr','status_id','1','2'),(50,50,'attr','status_id','1','2');
/*!40000 ALTER TABLE `journal_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-14 16:06:07
