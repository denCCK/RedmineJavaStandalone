-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: redmine
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `watchers`
--

DROP TABLE IF EXISTS `watchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `watchers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `watchable_type` varchar(255) NOT NULL DEFAULT '',
  `watchable_id` int NOT NULL DEFAULT '0',
  `user_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `watchers_user_id_type` (`user_id`,`watchable_type`),
  KEY `index_watchers_on_user_id` (`user_id`),
  KEY `index_watchers_on_watchable_id_and_watchable_type` (`watchable_id`,`watchable_type`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `watchers`
--

LOCK TABLES `watchers` WRITE;
/*!40000 ALTER TABLE `watchers` DISABLE KEYS */;
INSERT INTO `watchers` VALUES (1,'Issue',1,19),(2,'Issue',2,19),(3,'Issue',2,18),(4,'Issue',2,8),(5,'Issue',2,15),(6,'Issue',2,13),(7,'Issue',2,16),(8,'Issue',2,6),(9,'Issue',2,22),(10,'Issue',2,5),(11,'Issue',2,9),(12,'Issue',1,1),(13,'Issue',2,1),(14,'Issue',3,19),(15,'Issue',3,18),(16,'Issue',3,8),(17,'Issue',3,15),(18,'Issue',3,13),(19,'Issue',3,16),(20,'Issue',3,6),(21,'Issue',3,22),(22,'Issue',3,5),(23,'Issue',3,9),(24,'Issue',3,1),(25,'Issue',4,21),(26,'Issue',5,21),(27,'Issue',5,17),(28,'Issue',5,10),(29,'Issue',5,11),(30,'Issue',4,1),(31,'Issue',5,1),(32,'Issue',6,19),(33,'Issue',7,19),(34,'Issue',7,1),(35,'Issue',6,1),(36,'Issue',8,19),(37,'Issue',8,1),(38,'Issue',8,18),(39,'Issue',8,8),(40,'Issue',8,15),(41,'Issue',8,13),(42,'Issue',8,16),(43,'Issue',8,6),(44,'Issue',8,22),(45,'Issue',8,5),(46,'Issue',8,9),(47,'Issue',9,19),(48,'Issue',9,1),(49,'Issue',9,18),(50,'Issue',9,8),(51,'Issue',9,15),(52,'Issue',9,13),(53,'Issue',9,16),(54,'Issue',9,6),(55,'Issue',9,22),(56,'Issue',9,5),(57,'Issue',9,9),(58,'Issue',10,19),(59,'Issue',10,1),(60,'Issue',11,19),(61,'Issue',11,1),(62,'Issue',11,18),(63,'Issue',11,8),(64,'Issue',11,15),(65,'Issue',11,13),(66,'Issue',11,16),(67,'Issue',11,6),(68,'Issue',11,22),(69,'Issue',11,5),(70,'Issue',11,9),(71,'Issue',12,21),(72,'Issue',12,1),(73,'Issue',13,22),(74,'Issue',13,11),(75,'Issue',14,22),(76,'Issue',14,11),(77,'Issue',15,10),(78,'Issue',16,22),(79,'Issue',16,11),(80,'Issue',14,1),(81,'Issue',16,1),(82,'Issue',17,10),(83,'Issue',15,1),(84,'Issue',18,22),(85,'Issue',18,11),(86,'Issue',19,22),(87,'Issue',19,11),(88,'Issue',19,1),(89,'Issue',13,1),(90,'Issue',18,1);
/*!40000 ALTER TABLE `watchers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-14 16:06:09
