-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: redmine
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `login` varchar(255) NOT NULL DEFAULT '',
  `hashed_password` varchar(40) NOT NULL DEFAULT '',
  `firstname` varchar(30) NOT NULL DEFAULT '',
  `lastname` varchar(255) NOT NULL DEFAULT '',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '1',
  `last_login_on` datetime DEFAULT NULL,
  `language` varchar(5) DEFAULT '',
  `auth_source_id` int DEFAULT NULL,
  `created_on` timestamp NULL DEFAULT NULL,
  `updated_on` timestamp NULL DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `mail_notification` varchar(255) NOT NULL DEFAULT '',
  `salt` varchar(64) DEFAULT NULL,
  `must_change_passwd` tinyint(1) NOT NULL DEFAULT '0',
  `passwd_changed_on` datetime DEFAULT NULL,
  `twofa_scheme` varchar(255) DEFAULT NULL,
  `twofa_totp_key` varchar(255) DEFAULT NULL,
  `twofa_totp_last_used_at` int DEFAULT NULL,
  `twofa_required` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `index_users_on_id_and_type` (`id`,`type`),
  KEY `index_users_on_auth_source_id` (`auth_source_id`),
  KEY `index_users_on_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','c69638da25a81f040c52a20a55429c499d3e78b1','Redmine','Admin',1,1,'2023-03-14 10:33:10','',NULL,'2023-03-10 15:26:34','2023-03-10 16:03:49','User','all','c884ae310fb8a97c5c6dd0b3af36ab33',0,'2023-03-10 19:03:49',NULL,NULL,NULL,0),(2,'','','','Anonymous users',0,1,NULL,'',NULL,'2023-03-10 15:26:47','2023-03-10 15:26:47','GroupAnonymous','',NULL,0,NULL,NULL,NULL,NULL,0),(3,'','','','Non member users',0,1,NULL,'',NULL,'2023-03-10 15:26:47','2023-03-10 15:26:47','GroupNonMember','',NULL,0,NULL,NULL,NULL,NULL,0),(4,'','','','Anonymous',0,0,NULL,'',NULL,'2023-03-10 15:28:41','2023-03-10 15:28:41','AnonymousUser','only_my_events',NULL,0,NULL,NULL,NULL,NULL,0),(5,'fedorovK_1','d3af10cccf5038ef0d6caf7080d302f3315ad8eb','Константин','Федоров',0,1,NULL,'ru',NULL,'2023-03-14 07:45:26','2023-03-14 07:45:26','User','only_my_events','52eeb6682952b71fb3cacb15e78f0e4f',0,'2023-03-14 10:45:26',NULL,NULL,NULL,0),(6,'afansevE_1','907a5af2b0a3d817268ad60652b2902053f3082b','Евгений','Афанасьев',0,1,NULL,'ru',NULL,'2023-03-14 07:47:00','2023-03-14 07:47:00','User','only_my_events','4c26f6152f57d1b543f85861fc155973',0,'2023-03-14 10:47:00',NULL,NULL,NULL,0),(7,'petrovskayaS_1','14cdbdf7c4bb55474fde6f1472b31ba72ee2921a','София','Петровская',0,1,NULL,'en',NULL,'2023-03-14 07:47:53','2023-03-14 07:47:53','User','only_my_events','046c796136089fb3a110b7d2d9f11c86',0,'2023-03-14 10:47:53',NULL,NULL,NULL,0),(8,'smirnovA_1','a5e60ca5aff5606db79b4464c3204ba6c4f017d7','Арсений','Смирнов',0,1,NULL,'en',NULL,'2023-03-14 07:48:38','2023-03-14 07:48:38','User','only_my_events','aebd69ad0ed1b764f9ac2e0cb0ba847f',0,'2023-03-14 10:48:38',NULL,NULL,NULL,0),(9,'makarovN_1','9016b5fa8c29ba04634e10ad592336fa628a4075','Никита','Макаров',0,1,NULL,'en',NULL,'2023-03-14 07:49:17','2023-03-14 07:49:17','User','only_my_events','d4393afcf1858dc76d0175f352bbf55a',0,'2023-03-14 10:49:17',NULL,NULL,NULL,0),(10,'aleshinE_1','d5c6226ea9bee2838a330f75fbc80bd76293b4d9','Егор','Алешин',0,1,NULL,'en',NULL,'2023-03-14 07:50:02','2023-03-14 07:50:02','User','only_my_events','cc44aebb1ab6456f9e04a0f1355eb1c1',0,'2023-03-14 10:50:02',NULL,NULL,NULL,0),(11,'smirnovN_1','de4888033d2ed584d2319037aadaca918198e119','Никита','Смирнов',0,1,NULL,'en',NULL,'2023-03-14 07:50:45','2023-03-14 07:50:45','User','only_my_events','2b4ffe4cdde3f2a7a7865a50720d7e62',0,'2023-03-14 10:50:45',NULL,NULL,NULL,0),(12,'selivanovaD_1','589949a020d9be933cd12c51d4469a311c651e02','Диана','Селиванова',0,1,NULL,'ru',NULL,'2023-03-14 08:38:07','2023-03-14 08:38:07','User','only_my_events','30dff01ce5c9ef44846d5059febb5965',0,'2023-03-14 11:38:07',NULL,NULL,NULL,0),(13,'lapinG_1','9bb81021ee3a49cca57e1f598bf76bfa4ecd75f6','Георгий','Лапин',0,1,NULL,'en',NULL,'2023-03-14 08:38:51','2023-03-14 08:38:51','User','only_my_events','2159b58458d4649b8b9e297dcc365f47',0,'2023-03-14 11:38:51',NULL,NULL,NULL,0),(14,'shukinA_1','554db15753e59d53f5246e126accfe9fda715c68','Александр','Щукин',0,1,NULL,'ru',NULL,'2023-03-14 08:39:37','2023-03-14 08:39:37','User','only_my_events','128829c3f339fb08d336fef1dad0c435',0,'2023-03-14 11:39:37',NULL,NULL,NULL,0),(15,'kozlovA_1','f096edcc1afe3ad84b3d0e05243eaafd9dac22f1','Артём','Козлов',0,1,NULL,'en',NULL,'2023-03-14 08:40:40','2023-03-14 08:40:40','User','only_my_events','a0c033479989279f9b6fbcf2400be1a0',0,'2023-03-14 11:40:40',NULL,NULL,NULL,0),(16,'lazarevD_1','9b44cc273638e5e27518cef2b15d089202fee266','Дмитрий','Лазарев',0,1,NULL,'en',NULL,'2023-03-14 08:41:26','2023-03-14 08:41:26','User','only_my_events','5990ef40e41e5efc273a98da29ba473c',0,'2023-03-14 11:41:26',NULL,NULL,NULL,0),(17,'lebedevV_1','28d34c9c66b4872bd36d2262bee3ffc1e72d8d24','Вячеслав','Лебедев',0,1,NULL,'en',NULL,'2023-03-14 08:42:06','2023-03-14 08:42:06','User','only_my_events','f8c08a5f3f5b7ff6f2eec47e0b7d4b07',0,'2023-03-14 11:42:06',NULL,NULL,NULL,0),(18,'kazakovaA_1','5b95fc6f112632cb80414ebb3033c2fc942dbb78','Алиса','Казакова',0,1,NULL,'en',NULL,'2023-03-14 08:42:41','2023-03-14 08:42:41','User','only_my_events','2d23d6f9d93fb9381e83ac955da1ac09',0,'2023-03-14 11:42:41',NULL,NULL,NULL,0),(19,'','','','Команда разработчиков',0,1,NULL,'',NULL,'2023-03-14 08:43:18','2023-03-14 08:43:18','Group','',NULL,0,NULL,NULL,NULL,NULL,0),(20,'','','','Команда менеджеров',0,1,NULL,'',NULL,'2023-03-14 08:43:35','2023-03-14 08:45:44','Group','',NULL,0,NULL,NULL,NULL,NULL,0),(21,'','','','Команда репортеров',0,1,NULL,'',NULL,'2023-03-14 08:43:51','2023-03-14 08:43:51','Group','',NULL,0,NULL,NULL,NULL,NULL,0),(22,'tkachevE_1','3077291d99628bf97efa00a28e8d7c228203d11b','Евгений','Ткачев',0,1,NULL,'ru',NULL,'2023-03-14 08:45:32','2023-03-14 08:45:32','User','only_my_events','c13239b26b12f1e0313f30953e1411d5',0,'2023-03-14 11:45:32',NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-14 16:06:10
