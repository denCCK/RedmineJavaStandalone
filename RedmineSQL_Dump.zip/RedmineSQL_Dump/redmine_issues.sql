-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: redmine
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `issues`
--

DROP TABLE IF EXISTS `issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `issues` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tracker_id` int NOT NULL,
  `project_id` int NOT NULL,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `description` longtext,
  `due_date` date DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `status_id` int NOT NULL,
  `assigned_to_id` int DEFAULT NULL,
  `priority_id` int NOT NULL,
  `fixed_version_id` int DEFAULT NULL,
  `author_id` int NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  `created_on` timestamp NULL DEFAULT NULL,
  `updated_on` timestamp NULL DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `done_ratio` int NOT NULL DEFAULT '0',
  `estimated_hours` float DEFAULT NULL,
  `parent_id` int DEFAULT NULL,
  `root_id` int DEFAULT NULL,
  `lft` int DEFAULT NULL,
  `rgt` int DEFAULT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `closed_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `issues_project_id` (`project_id`),
  KEY `index_issues_on_status_id` (`status_id`),
  KEY `index_issues_on_category_id` (`category_id`),
  KEY `index_issues_on_assigned_to_id` (`assigned_to_id`),
  KEY `index_issues_on_fixed_version_id` (`fixed_version_id`),
  KEY `index_issues_on_tracker_id` (`tracker_id`),
  KEY `index_issues_on_priority_id` (`priority_id`),
  KEY `index_issues_on_author_id` (`author_id`),
  KEY `index_issues_on_created_on` (`created_on`),
  KEY `index_issues_on_root_id_and_lft_and_rgt` (`root_id`,`lft`,`rgt`),
  KEY `index_issues_on_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issues`
--

LOCK TABLES `issues` WRITE;
/*!40000 ALTER TABLE `issues` DISABLE KEYS */;
INSERT INTO `issues` VALUES (1,2,2,'Функциональная возможность 1','Реализовать функциональную возможность 1','2023-03-28',NULL,2,14,2,1,1,2,'2023-03-14 09:36:10','2023-03-14 10:08:24','2023-03-14',0,56,NULL,1,1,2,0,NULL),(2,2,2,'Функциональная возможность 2','Реализовать функциональную возможность 2','2023-04-02',NULL,2,14,1,1,1,3,'2023-03-14 09:39:30','2023-03-14 10:08:35','2023-03-14',60,20,NULL,2,1,2,0,NULL),(3,2,2,'Функциональная возможность 3','Реализовать функциональную возможность 3',NULL,NULL,2,14,2,1,1,4,'2023-03-14 09:40:38','2023-03-14 10:09:03','2023-03-14',20,25,NULL,3,1,2,0,NULL),(4,1,2,'Исправление ошибки 1 категории B','Отследить и исправить ошибку 1 категории В',NULL,NULL,4,12,4,1,1,3,'2023-03-14 09:45:14','2023-03-14 10:25:05','2023-03-14',30,5,NULL,4,1,2,0,NULL),(5,1,2,'Исправление ошибки 1 категории А','Отследить и исправить ошибку 1 категории А',NULL,NULL,2,12,5,1,1,4,'2023-03-14 09:45:54','2023-03-14 10:08:48','2023-03-14',10,5,NULL,5,1,2,0,NULL),(6,3,2,'Замена встроенных библиотек','Замена встроенных библиотек на более производительные решения',NULL,NULL,6,7,3,1,1,2,'2023-03-14 09:51:48','2023-03-14 10:08:57','2023-03-14',0,5,NULL,6,1,2,0,'2023-03-14 13:08:57'),(7,2,2,'Функциональная возможность 1','Реализовать функциональную возможность 1',NULL,NULL,5,14,2,2,1,2,'2023-03-14 10:07:54','2023-03-14 10:08:13','2023-03-10',100,NULL,NULL,7,1,2,0,'2023-03-14 13:08:13'),(8,2,2,'Функциональная возможность 2','Реализовать функциональную возможность 2',NULL,NULL,5,14,2,2,1,4,'2023-03-14 10:15:10','2023-03-14 10:16:01','2023-03-10',100,NULL,NULL,8,1,2,0,'2023-03-14 13:16:01'),(9,2,2,'Функциональная возможность 3','Реализовать функциональную возможность 3',NULL,NULL,5,14,2,2,1,5,'2023-03-14 10:15:32','2023-03-14 10:16:06','2023-03-10',100,NULL,NULL,9,1,2,0,'2023-03-14 13:16:06'),(10,2,2,'Функциональная возможность 1','Реализовать функциональную возможность 1',NULL,NULL,5,14,2,3,1,4,'2023-03-14 10:17:08','2023-03-14 10:19:07','2023-03-11',100,40,NULL,10,1,2,0,'2023-03-14 13:19:07'),(11,2,2,'Функциональная возможность 2','Реализовать функциональную возможность 2',NULL,NULL,5,14,2,3,1,4,'2023-03-14 10:17:38','2023-03-14 10:19:12','2023-03-11',100,10,NULL,11,1,2,0,'2023-03-14 13:19:12'),(12,1,2,'Исправление ошибки 1 категории B','Исправление ошибки 2 категории B',NULL,NULL,5,12,3,4,1,2,'2023-03-14 10:23:46','2023-03-14 10:24:02','2023-03-12',100,5,NULL,12,1,2,0,'2023-03-14 13:24:02'),(13,2,3,'Функциональная возможность 1','Функциональная возможность 1','2023-03-31',NULL,2,14,3,5,1,2,'2023-03-14 10:30:52','2023-03-14 10:55:53','2023-03-14',20,5,NULL,13,1,2,0,NULL),(14,2,3,'Функциональная возможность 2','','2023-03-31',NULL,2,14,5,5,1,2,'2023-03-14 10:31:50','2023-03-14 10:55:57','2023-03-14',0,20,NULL,14,1,2,0,NULL),(15,1,3,'Дебагинг','',NULL,NULL,1,14,2,5,1,2,'2023-03-14 10:32:20','2023-03-14 10:33:54','2023-03-14',0,NULL,NULL,15,1,4,0,NULL),(16,2,3,'Функциональная возможность 3','','2023-03-31',NULL,1,14,3,5,1,3,'2023-03-14 10:33:05','2023-03-14 10:33:17','2023-03-14',60,14,NULL,16,1,2,0,NULL),(17,1,3,'Исправление ошибки 1 категории B','',NULL,NULL,1,14,2,5,1,0,'2023-03-14 10:33:54','2023-03-14 10:33:54','2023-03-14',0,NULL,15,15,2,3,0,NULL),(18,2,3,'Функциональная возможность 4','','2023-03-31',NULL,2,14,1,5,1,5,'2023-03-14 10:34:49','2023-03-14 10:56:07','2023-03-14',90,7,NULL,18,1,2,0,NULL),(19,2,3,'Функциональная возможность 5','','2023-03-31',NULL,5,14,1,5,1,6,'2023-03-14 10:35:24','2023-03-14 10:35:31','2023-03-14',100,7,NULL,19,1,2,0,'2023-03-14 13:35:31');
/*!40000 ALTER TABLE `issues` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-14 16:06:10
